export const Seat = () => {
    return(
        <div>
            Seat
        </div>
    );
}

export default Seat;