export const Table = ({index}) => {
    return(
        <div>
            <h2>Stůl: {index + 1}</h2>
        </div>
    );
}

export default Table;