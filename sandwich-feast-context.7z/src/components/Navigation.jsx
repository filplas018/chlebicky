export const Navigation = () => {
    return(
        <div>
            Nav
        </div>
    );
}

export default Navigation;